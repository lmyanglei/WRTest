package rtx;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
   
public class Signauth 
 {
    public boolean auth(String strUser, String strSign) 
    {
       	boolean bRet = false;
       	strSign = java.net.URLEncoder.encode(strSign,"GB2312");
       	String strURL = "http://127.0.0.1:8012/SignAuth.cgi?user=" + strUser + "&sign=" + strSign;
      	String szEncodeResult;
      	String szResult;

        try
        {
        	java.net.URL url = new URL(strURL);
        	HttpURLConnection httpConnection = (HttpURLConnection)url.openConnection();
        
        	BufferedReader reader = new BufferedReader(new InputStreamReader(httpConnection.getInputStream()));   
        	String strResult=reader.readLine();  
        
        	if(strResult.compareToIgnoreCase("success!") == 0)
        	{
        		bRet = true;
        	}
        
        }
        catch(Exception e)
        {
        	System.out.println("ϵͳ����"+e);
        }
        
		return bRet;
    }

}


